This repository is locked pending the release of KiCad version 5. No new pull requests will be accepted here. 

All new additions to this library should be directed to the new [https://github.com/kicad/kicad-footprints](kicad-footprints) repository, which is the new footprints repository for KiCad v5
